<?php
// WINQER LP Theme Functions

// Add title tag support
add_theme_support('title-tag');

// Enqueue styles/scripts if needed (currently using CDN directly in index.php for portability)
// Note: In a real production build, you might want to enqueue local assets here.
